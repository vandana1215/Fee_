import React from 'react'
import './App.css'
import First from './Componets/Firstpage'

function App() {


  return (
    <>
      <First/>
    </>
  )
}

export default App
